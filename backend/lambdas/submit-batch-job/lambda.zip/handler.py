"""
Lambda function to submit jobs to AWS Batch for TotalSegmentator processing
"""
import json
import os
import time
import boto3

batch = boto3.client('batch')
dynamodb = boto3.resource('dynamodb')

# Environment variables
JOB_QUEUE = os.environ['BATCH_JOB_QUEUE']
JOB_DEFINITION = os.environ['BATCH_JOB_DEFINITION']
S3_BUCKET = os.environ['S3_BUCKET']
DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE']

table = dynamodb.Table(DYNAMODB_TABLE)

def lambda_handler(event, context):
    """
    Submit a TotalSegmentator processing job to AWS Batch
    
    Expected input:
    {
        "jobId": "abc123",
        "device": "gpu",  # or "cpu"
        "fast": true,
        "reduction_percent": 90
    }
    """
    try:
        # Parse request
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', event)  # Support direct invocation
        
        job_id = body.get('jobId')
        device = body.get('device', 'gpu')
        fast = body.get('fast', True)
        reduction_percent = body.get('reduction_percent', 90)
        
        if not job_id:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'ok': False, 'error': 'jobId is required'})
            }
        
        print(f"Submitting Batch job for {job_id}")
        
        # Get job metadata from DynamoDB
        response = table.get_item(Key={'jobId': job_id})
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'ok': False, 'error': 'Job not found'})
            }
        
        job = response['Item']
        input_s3_key = job.get('inputFile')
        
        if not input_s3_key:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'ok': False, 'error': 'No input file found for job'})
            }
        
        # Submit job to AWS Batch
        batch_job_name = f"totalseg-{job_id}"
        s3_output_prefix = f"results/{job_id}/"
        
        batch_response = batch.submit_job(
            jobName=batch_job_name,
            jobQueue=JOB_QUEUE,
            jobDefinition=JOB_DEFINITION,
            containerOverrides={
                'environment': [
                    {'name': 'JOB_ID', 'value': job_id},
                    {'name': 'S3_BUCKET', 'value': S3_BUCKET},
                    {'name': 'S3_INPUT_KEY', 'value': input_s3_key},
                    {'name': 'S3_OUTPUT_PREFIX', 'value': s3_output_prefix},
                    {'name': 'DEVICE', 'value': device},
                    {'name': 'FAST', 'value': str(fast).lower()},
                    {'name': 'REDUCTION_PERCENT', 'value': str(reduction_percent)},
                    {'name': 'DYNAMODB_TABLE', 'value': DYNAMODB_TABLE}
                ]
            },
            retryStrategy={
                'attempts': 1  # Don't retry on failure
            },
            timeout={
                'attemptDurationSeconds': 3600  # 1 hour timeout
            }
        )
        
        batch_job_id = batch_response['jobId']
        
        print(f"Batch job submitted: {batch_job_id}")
        
        # Update DynamoDB with Batch job info
        table.update_item(
            Key={'jobId': job_id},
            UpdateExpression='SET #status = :status, batchJobId = :batchJobId, queuedAt = :now, updatedAt = :now, processingParams = :params',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':status': 'queued',
                ':batchJobId': batch_job_id,
                ':now': int(time.time()),
                ':params': {
                    'device': device,
                    'fast': fast,
                    'reduction_percent': reduction_percent,
                    's3_input_key': input_s3_key,
                    's3_output_prefix': s3_output_prefix
                }
            }
        )
        
        return {
            'statusCode': 202,
            'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'ok': True,
                'jobId': job_id,
                'batchJobId': batch_job_id,
                'status': 'queued',
                'message': 'Job queued for processing. GPU instance will start automatically.',
                'estimatedTime': '5-15 minutes (instance startup + processing)'
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Update job status to failed
        if 'job_id' in locals():
            try:
                table.update_item(
                    Key={'jobId': job_id},
                    UpdateExpression='SET #status = :status, errorMessage = :error, updatedAt = :now',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':status': 'failed',
                        ':error': str(e),
                        ':now': int(time.time())
                    }
                )
            except:
                pass
        
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'ok': False,
                'error': str(e)
            })
        }
